
"use strict";

let Pesan = require('./Pesan.js');

module.exports = {
  Pesan: Pesan,
};
