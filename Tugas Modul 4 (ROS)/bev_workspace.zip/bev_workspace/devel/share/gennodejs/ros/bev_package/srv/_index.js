
"use strict";

let service = require('./service.js')

module.exports = {
  service: service,
};
